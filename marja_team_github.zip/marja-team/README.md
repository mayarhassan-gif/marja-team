# موقع فريق مَرَجِع

## نشر الموقع مجانًا عبر GitHub Pages

1. سجّلي الدخول إلى https://github.com
2. اضغطي **New repository**.
3. اكتبي اسم المستودع: `marja-team` واجعليه **Public**، ثم أنشئيه.
4. اختاري **Add file** ثم **Upload files**.
5. ارفعي ملف `index.html` الموجود في هذه الحزمة، ثم اضغطي **Commit changes**.
6. افتحي **Settings** ثم **Pages**.
7. تحت **Build and deployment** اختاري **Deploy from a branch**.
8. اختاري الفرع `main` والمجلد `/ (root)` ثم **Save**.
9. انتظري قليلًا، وسيظهر رابط الموقع في صفحة Pages، غالبًا بهذا الشكل:
   `https://YOUR-USERNAME.github.io/marja-team/`

استبدلي `YOUR-USERNAME` باسم مستخدم GitHub الخاص بك.

الروابط تفتح حسابات LinkedIn في تبويب جديد.
